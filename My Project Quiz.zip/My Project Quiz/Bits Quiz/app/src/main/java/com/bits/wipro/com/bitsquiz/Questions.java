package com.bits.wipro.com.bitsquiz;



public class Questions {

    private String mQuestion [] ={

             "What is the name of APPLE CEO ?",
             "What is the name of WIPRO CEO ?",
             "What is the name of GOOGLE CEO ?",
             "What is the name of MICROSOFT CEO ?",
             "What is the name of IBM CEO ?",
             "What is the name of TCS CEO ?"



    };

    private String mChoices[][] = {

            {"Tim Cook","Ginni Rometty","Abidali Neemuchwala"},
            {"Abidali Neemuchwala","Ginni Rometty","Tim Cook"},
            {"Ginni Rometty","Sundar Pichai","Tim Cook"},
            {"Abidali Neemuchwala","Satya Nadella","Tim Cook"},
            {"Satya Nadella","Ginni Rometty","Ginni Rometty"},
            {"Rajesh Gopinathan ","Sundar Pichai","Tim Cook"},



    };


    private String  mCorrectAnswers[] =  {"Tim Cook","Abidali Neemuchwala","Sundar Pichai","Satya Nadella","Ginni Rometty","Rajesh Gopinathan"};

    public String getQuestion(int a) {
        String question =mQuestion[a];
        return question;
    }
        public String getChoice1(int a){
        String choice0 = mChoices[a][0];
        return choice0;
    }

    public String getChoice2(int a){
        String choice1 = mChoices[a][1];
        return choice1;
    }
    public String getChoice3(int a){
        String choice2 = mChoices[a][2];
        return choice2;
    }

    public String getCorrectAnswer(int a){

        String answer = mCorrectAnswers[a];
        return  answer;
    }






}




